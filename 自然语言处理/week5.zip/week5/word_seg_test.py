# encoding=utf-8

# 加载字典
def load_word_list():
    max_length = 0
    word_dict = set()
    for line in open('./data/corpus.dict.txt',encoding='utf-8',errors='ignore').readlines():
        tmp = len(line)
        if(max_length < tmp):
            max_length = tmp
        word_dict.add(line.strip())
    return {
            'max_length':max_length,
            'word_dict':word_dict
            }
#with start include and end outclude
def substring(_string,start,end):
	import string
	res = ''
	if start >= end:
		return res
	for i in range(start,end):
		res += _string[i]
	return res
# 最大正向匹配
def max_left_match(line,dict,max_length):
    #return a set of string that are splitted 
	res = []
	
	while not line=='':#
		if(line.isspace()):
			line = ''
			continue;
		max_length = min(max_length,len(line))
		for i in range(max_length,0,-1):
			#take substring of line
			sub=substring(line,0,i)
			exist = False
			for word in dict:
				if word == sub:
					exist = True
					break;
			if(exist or i==1):
				res.append(sub)
				line = substring(line,i,len(line))
				break
			else:
				continue
				
	return res
# 测试
def main():
	import re
	import string
	#open file to write output
	fout = open("./output/corpus.out.txt",encoding="utf-8",mode="w")
	#load dictionary
	res = load_word_list()
	max_length = res['max_length']
	word_dict=res['word_dict']

	#write the expression to remove punctations
	illegal_char=r"[！。，？‘“”’；：——、]"
	pattern=re.compile(illegal_char)
	#read lines of sentence file
	lines = open('./data/corpus.sentence.txt',encoding='utf-8',errors='ignore').readlines()
	new_lines=[]
	lineswithoutpunctuation = []
	for line in lines:
		new_line = pattern.sub(u'',line)
		if(not new_line.isspace()):
    			lineswithoutpunctuation.append(new_line)
		new_line = max_left_match(new_line,word_dict,max_length)
		new_lines.extend(new_line)
	print(new_lines)
	for word in new_lines:
		fout.write(word+"/")
	#remove punctuate
	fout.close()

	#word tokenize
	fout = open("./output/tokenzation_result.txt",mode="w",encoding="utf-8")
	import jieba.posseg as pseg
	token_result = []
	for word in lineswithoutpunctuation:
		tokens = pseg.cut(word)
		for w in tokens:
			print(w.word,w.flag)
			fout.writelines(w.word+" "+w.flag+'\n')
	fout.close()
main()
