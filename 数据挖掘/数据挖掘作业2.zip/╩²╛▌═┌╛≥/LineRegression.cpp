#include "LineRegression.h"
#include<time.h>


LineRegression::LineRegression()
{
}


LineRegression::~LineRegression()
{
	ArrayAllocHelper::deallocate(this->trainingX, trainingDataNum);
	ArrayAllocHelper::deallocate(this->testingX, testingDataNum);
	ArrayAllocHelper::deallocate(this->trainingY);
	ArrayAllocHelper::deallocate(this->testingY);
	ArrayAllocHelper::deallocate(this->parameters);
	//ArrayAllocHelper::deallocate(this->scales);
	ArrayAllocHelper::deallocate(this->trainingloss);
	ArrayAllocHelper::deallocate(this->testingloss);
	ArrayAllocHelper::deallocate(this->parameters_recording,iteration_times/record_frequency);
	ArrayAllocHelper::deallocate(mean);
	ArrayAllocHelper::deallocate(standard_variance);
}

void LineRegression::setTestingDataSet(double**& X, double* & Y,int num,int dimension)
{
	ArrayAllocHelper::deallocate(testingX,this->dataDimension);
	ArrayAllocHelper::deallocate(testingY);
	//copy testingx
	this->testingX = ArrayAllocHelper::copy(X, dimension, num);
	this->testingY = ArrayAllocHelper::copy(Y, num);
	this->dataDimension = dimension;
	this->testingDataNum = num;
	return ;
}

void LineRegression::setTrainingDataSet(double** & x, double*& y,int num,int dimension)
{
	ArrayAllocHelper::deallocate(trainingX, dataDimension);
	ArrayAllocHelper::deallocate(trainingY);
	this->trainingX = ArrayAllocHelper::copy(x, dimension, num);
	this->trainingY = ArrayAllocHelper::copy(y, num);
	this->dataDimension = dimension;
	this->trainingDataNum = num;
	return ;
}

void LineRegression::setIterationTimes(int times)
{
	assert(times > 0);
	iteration_times = times;
}

void LineRegression::setRecordFrequency(int times)
{
	assert(times > 0);
	record_frequency = times;
}

void LineRegression::setLearningRate(double learning_rate)
{
	assert(learning_rate > 0);
	this->learning_rate = learning_rate;
}

void LineRegression::gradient_descent(GRADIENT_DESENT_TYPE gradient_decent_type)
{
	//set seed for rand
	if (gradient_decent_type == STOCHASTIC) {
		srand(unsigned(time(0)));
	}
	//backup trainingx and testingx
	auto trainx = getTrainingX();
	auto testx = getTestingX();
	normalization();
	//************************init**********************************
	ArrayAllocHelper::deallocate(trainingloss);
	ArrayAllocHelper::deallocate(testingloss);
	trainingloss = ArrayAllocHelper::make(iteration_times/record_frequency,100000000.0);
	testingloss = ArrayAllocHelper::make(iteration_times / record_frequency,100000000.0);
	recordNum = 0;
	ArrayAllocHelper::deallocate(parameters_recording, iteration_times / record_frequency);
	parameters_recording = ArrayAllocHelper::make(iteration_times / record_frequency, parameterSize);

	//***********************iteration start***********************************
	for (int i = 0; i < iteration_times; i++) {
		if (i % record_frequency == 0 && i != 0) {
			//cout << i << endl;
			trainingloss[recordNum] = calculate_loss(trainingX, trainingY, parameters, trainingDataNum, dataDimension);
			testingloss[recordNum] = calculate_loss(testingX, testingY, parameters, testingDataNum, dataDimension);
			for (int j = 0; j < parameterSize; j++) {
				parameters_recording[recordNum][j] = parameters[j];
			}
			recordNum++;
		}
		//get gradient and update parameters
		auto gradient = getGradient(gradient_decent_type);
		for (int i = 0; i < parameterSize; i++) {
			parameters[i] += gradient[i] * learning_rate;
			
		}
		ArrayAllocHelper::deallocate(gradient);
	}

	//************************recover training data x, testing data x,parameters from normalization*************
	ArrayAllocHelper::deallocate(trainingX, dataDimension);
	ArrayAllocHelper::deallocate(testingX, dataDimension);
	trainingX = trainx;
	testingX = testx;
	double temp = parameters[dataDimension];
	for (int i = 0; i < dataDimension; i++) {
		temp -= parameters[i] * mean[i] / standard_variance[i];
		parameters[i] /= standard_variance[i];
	}
	for (int i = 0; i < iteration_times / record_frequency; i++) {
		double sum = parameters_recording[i][dataDimension];
		for (int j = 0; j < dataDimension; j++) {
			sum -= parameters_recording[i][j] * mean[j] / standard_variance[j];
			parameters_recording[i][j] /= standard_variance[j];
		}
		parameters_recording[i][dataDimension] = sum;
	}
	parameters[dataDimension] = temp;

	//******************print information of trainingloss and testingloss
	showDebugInfo();
}

void LineRegression::setParameters(double* & paras,int num)
{
	if (parameterSize != num) {
		ArrayAllocHelper::deallocate(parameters);
		
		this->parameters = ArrayAllocHelper::copy(paras, num);
		this->parameterSize = num;
	}
	else {
		for (int i = 0; i < num; i++) {
			parameters[i] = paras[i];
		}
	}
	return;
}

void LineRegression::resetParameters()
{
	if (this->parameterSize != this->dataDimension + 1) {
		ArrayAllocHelper::deallocate(this->parameters);
		this->parameters = ArrayAllocHelper::make(dataDimension + 1);
		this->parameterSize = dataDimension + 1;
	}
	else {
		for (int i = 0; i < parameterSize; i++) {
			parameters[i] = 0.0;
		}
	}
}

double * LineRegression::getGradient(GRADIENT_DESENT_TYPE type)
{
	double *res = ArrayAllocHelper::make(parameterSize);
	if (type == LineRegression::BATCH) {
		for (int i = 0; i < trainingDataNum; i++) 
		{
			double y = trainingY[i];
			double fx = 0.0;
			for (int j = 0; j < dataDimension; j++) {
				fx += parameters[j] * trainingX[j][i];
			}
			fx += parameters[dataDimension]*1.0;
			for (int j = 0; j < dataDimension; j++) {
				res[j] += (y - fx)*trainingX[j][i];
			}
			res[dataDimension] += (y - fx)*1.0;
		}
		for (int i = 0; i < parameterSize; i++) {
			res[i] /= trainingDataNum;
		}
		return res;
	}
	else if (type == LineRegression::STOCHASTIC) {
		int index = rand()*1.0 / RAND_MAX * trainingDataNum;
		if (index >= trainingDataNum) {
			index = trainingDataNum-1;
		}
		double y = trainingY[index];
		double fx = 0.0;
		for (int i = 0; i < dataDimension; i++) {
			fx += parameters[i] * trainingX[i][index];
		}
		fx += parameters[dataDimension]*1.0;
		for (int i = 0; i < dataDimension; i++) {
			res[i] += (y - fx)*trainingX[i][index];
		}
		res[dataDimension] = (y - fx)*1.0;
		return res;
	}
	else {
		system("exit");
	}
}
void LineRegression::showDebugInfo()
{
	
	cout << "training data num:\t" << trainingDataNum << endl;
	cout << "testing data num:\t" << testingDataNum << endl;
	cout << "data dimension:\t" << dataDimension << endl;
	cout << "parameter size:\t" << parameterSize << endl;
	cout << "training data:" << endl;
	for (int i = 0; i < trainingDataNum; i++) {
		cout << i << "\t" << trainingX[0][i] << "\t" << trainingX[1][i] << "\t" << trainingY[i] 
			<< "\t"<<trainingX[0][i]*parameters[0]+trainingX[1][i]*parameters[1]+parameters[2] << endl;
	}
	cout << "testing data:" << endl;
	for (int i = 0; i < testingDataNum; i++) {
		cout << i << "\t" << testingX[0][i] << "\t" << testingX[1][i] << "\t" << testingY[i] 
			<< "\t" << testingX[0][i] * parameters[0] + testingX[1][i] * parameters[1] + parameters[2] << endl;
	}
	cout << "paraA:\t\t" << "parab\t\t" << "bias\t\t" << "training loss\t\t" << "testing loss" << endl;
	for (int i = 0; i < iteration_times / record_frequency; i++) {
		cout << parameters_recording[i][0] << "\t" << parameters_recording[i][1] << "\t" << parameters_recording[i][2] << "\t" << trainingloss[i] <<"\t"<<testingloss[i]<< endl;
	}
}
/*assert x i,j >= 0
normalize training x and testing x in same dimension to 0,1 
*/
void LineRegression::normalization()
{
	//standardalization
	ArrayAllocHelper::deallocate(mean);
	ArrayAllocHelper::deallocate(standard_variance);
	mean = ArrayAllocHelper::make(dataDimension,0.0);
	standard_variance = ArrayAllocHelper::make(dataDimension, 0.0);
	for (int i = 0; i < dataDimension; i++) {
		double mean_ = 0.0;
		for (int j = 0; j < trainingDataNum; j++) {
			mean_ += trainingX[i][j] / trainingDataNum;
		}
		mean[i] = mean_;
		double svar = 0.0;
		for (int j = 0; j < trainingDataNum; j++) {
			svar += pow(trainingX[i][j] - mean_, 2)/trainingDataNum;
		}
		svar = pow(svar, 0.5);
		standard_variance[i] = svar;
		for (int j = 0; j < trainingDataNum; j++) {
			trainingX[i][j] = (trainingX[i][j] - mean_) / svar;
		}
		for (int j = 0; j < testingDataNum; j++) {
			testingX[i][j] = (testingX[i][j] - mean_) / svar;
		}
	}
}

double LineRegression::calculate_loss(double** & x, double *& y, double* &paras,int num,int dataDimension)
{
	//E((Y-X*PARA)^2)
	double sum = 0;
	for (int i = 0; i < num; i++) {
		double temp = 0;
		for (int j = 0; j < dataDimension; j++) {
			temp += x[j][i] * paras[j];
		}
		temp += 1.0*paras[dataDimension];
		sum += pow(y[i] - (temp), 2);
	}
	return sum / num/2;
}

double* LineRegression::getParameters(bool scaled )
{
	auto res = ArrayAllocHelper::copy(parameters, parameterSize);
	return res;
}

double * LineRegression::getTrainingY()
{
	auto res = ArrayAllocHelper::copy(trainingY, trainingDataNum);
	return res;
}

double ** LineRegression::getTrainingX()
{
	auto res = ArrayAllocHelper::copy(trainingX, dataDimension, trainingDataNum);
	return res;
}

double** LineRegression::getTestingX()
{
	auto res = ArrayAllocHelper::copy(testingX, dataDimension, testingDataNum);
	return res;
}

double* LineRegression::getTestingY()
{
	auto res = ArrayAllocHelper::copy(testingY, testingDataNum);
	return res;
}

int LineRegression::getParameterSize()
{
	return parameterSize;
}
