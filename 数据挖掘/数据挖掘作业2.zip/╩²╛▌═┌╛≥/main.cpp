#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<sstream>
#include"LineRegression.h"
using namespace std;

//load data set
//area	distance	price
void split(std::string& s, std::string& delim, std::vector< std::string >* ret)
{
	size_t last = 0;
	size_t index = s.find_first_of(delim, last);
	while (index != std::string::npos)
	{
		ret->push_back(s.substr(last, index - last));
		last = index + 1;
		index = s.find_first_of(delim, last);
	}
	if (index - last > 0)
	{
		ret->push_back(s.substr(last, index - last));
	}
}
void load_data_set(string path, double* & areas, double* & dists, double* & price, int & _count) {
	auto cstr = path.c_str();
	ifstream fin(cstr);
	//stringstream ss = fout;
	char buffer[256];
	int index = 0;
	while (!fin.eof()) {
		fin.getline(buffer, 100);
			//fin >> s;
		string s = string(buffer);
		string delim = " ";
		vector<string> ret;
		split(s, delim, &ret);
		double data[3];
		for (int i = 0; i < ret.size(); i++) {
			auto temp = ret[i];
			//double area, dist, price;
			stringstream ss;
			ss << temp;
			ss >> data[i];
			
			//cout << temp.c_str()<< endl;
		}
		areas[index] = data[0];
		dists[index] = data[1];
		price[index] = data[2];
		//cout << s.c_str() << endl;
		index++;
	}
	fin.close();
	_count = index;
}

int main() {
	
	double *areas = new double[50], *dists = new double[50], *prices = new double[50];
	double *areas_t = new double[50], *dists_t = new double[50], *prices_t = new double[50];
	int _count, _count_t;
	string path = "./data/dataForTraining.txt";
	load_data_set(path, areas, dists, prices, _count);
	path = "./data/dataForTesting.txt";
	load_data_set(path, areas_t, dists_t, prices_t, _count_t);
	double *  trainingy, *testingy;
	double ** trainingx, **testingx;
	trainingy = prices;
	testingy = prices_t;
	trainingx = ArrayAllocHelper::make(2, _count);
	testingx = ArrayAllocHelper::make(2, _count_t);
	for (int i = 0; i < _count; i++) {
		trainingx[0][i] = areas[i];
		trainingx[1][i] = dists[i];
	}
	for (int i = 0; i < _count_t; i++) {
		testingx[0][i] = areas_t[i];
		testingx[1][i] = dists_t[i];
	}

	//configuration for line regression
	auto lr = LineRegression();
	lr.setTrainingDataSet(trainingx, trainingy,_count,2);
	lr.setTestingDataSet(testingx, testingy,_count_t,2);
	lr.resetParameters();

	//exercise 1
	lr.setIterationTimes(150000);
	lr.setLearningRate(0.00015);

	lr.setRecordFrequency(10000);

	lr.gradient_descent(LineRegression::BATCH);

	auto para = lr.getParameters();
	for (int i = 0; i < lr.getParameterSize(); i++) {
		cout << para[i] << endl;
	}
	ArrayAllocHelper::deallocate(para);

	//exercise2
	lr.resetParameters();
	lr.setLearningRate(0.0002);
	lr.gradient_descent();
	para = lr.getParameters();
	for (int i = 0; i < lr.getParameterSize(); i++) {
		cout << para[i] << endl;
		
	}
	ArrayAllocHelper::deallocate(para);

	//exercise 3
	lr.resetParameters();
	lr.gradient_descent(LineRegression::STOCHASTIC);
	para = lr.getParameters();
	for (int i = 0; i < lr.getParameterSize(); i++) {
		cout << para[i] << endl;

	}
	ArrayAllocHelper::deallocate(para);
	while (true);
}