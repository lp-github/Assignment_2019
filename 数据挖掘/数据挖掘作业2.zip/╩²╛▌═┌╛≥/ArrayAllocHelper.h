#pragma once
class ArrayAllocHelper
{
public:
	ArrayAllocHelper();
	~ArrayAllocHelper();
	static double* make(int size, double init_value = 0.0);
	static double** make(int size1, int size2, double int_value = 0.0);
	static double* copy(double* & from, int size);
	static double** copy(double ** & from, int size1, int size2);
	static void deallocate(double *& arr);
	static void deallocate(double ** & arr, int size);
};

