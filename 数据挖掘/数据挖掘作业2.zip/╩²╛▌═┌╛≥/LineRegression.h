#pragma once
#include<vector>
#include<iostream>
#include<assert.h>
#include"ArrayAllocHelper.h"
using namespace std;
class LineRegression
{
public:
	typedef int GRADIENT_DESENT_TYPE;
	const static GRADIENT_DESENT_TYPE BATCH = 1;
	const static GRADIENT_DESENT_TYPE STOCHASTIC = 2;
	LineRegression();
	~LineRegression();
	void setTestingDataSet(double** &X, double*&Y,int num,int dimension);
	void setTrainingDataSet(double** &x, double *&y,int num,int dimension);
	void setIterationTimes(int times);
	void setRecordFrequency(int times);
	void setLearningRate(double learning_rate);
	void gradient_descent(GRADIENT_DESENT_TYPE gradient_decent_type = BATCH);
	void setParameters(double* &paras,int num);
	void resetParameters();
	double* getParameters(bool scaled = true);
	double* getTrainingY();
	double** getTrainingX();
	double **getTestingX();
	double* getTestingY();
	int getParameterSize();
private:
	double learning_rate=0.00015;
	int iteration_times = 1500000;
	int record_frequency = 100000;
	double *parameters;
	//double *scales;
	double **trainingX;
	double **testingX;
	double *trainingY;
	double *testingY;
	double * trainingloss;
	double * testingloss;
	double ** parameters_recording;
	double * mean;
	double * standard_variance;
	int trainingDataNum=0, dataDimension=0, testingDataNum=0,parameterSize=1,recordNum;
	
	//vector<double> getGradient(const vector<vector<double>> &Xs, const vector<double> & Y, const vector<double> &paras, GRADIENT_DESENT_TYPE type = BATCH);
	double* getGradient(GRADIENT_DESENT_TYPE type = BATCH);
	void showDebugInfo();
	void normalization();
	double calculate_loss(double ** & x,double * & y, double* &paras,
		int num,int dataDimension);
};