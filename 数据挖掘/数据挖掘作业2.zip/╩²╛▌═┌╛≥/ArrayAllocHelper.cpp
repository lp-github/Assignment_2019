#include "ArrayAllocHelper.h"



ArrayAllocHelper::ArrayAllocHelper()
{
}


ArrayAllocHelper::~ArrayAllocHelper()
{
}

double * ArrayAllocHelper::make(int size, double init_value)
{
	double * res = new double[size];
	for (int i = 0; i < size; i++) {
		res[i] = init_value;
	}
	return res;
}

double ** ArrayAllocHelper::make(int size1, int size2, double int_value)
{
	double **res = new double *[size1];
	for (int i = 0; i < size1; i++) {
		res[i] = new double[size2];
		for (int j = 0; j < size2; j++) {
			res[i][j] = int_value;
		}
	}
	return res;
}

double * ArrayAllocHelper::copy(double *& from, int size)
{
	auto res = make(size);
	for (int i = 0; i < size; i++) {
		res[i] = from[i];
	}
	return res;
}

double ** ArrayAllocHelper::copy(double **& from, int size1, int size2)
{
	auto res = make(size1, size2);
	for (int i = 0; i < size1; i++) {
		for (int j = 0; j < size2; j++) {
			res[i][j] = from[i][j];
		}
	}
	return res;
}

void ArrayAllocHelper::deallocate(double *& arr)
{
	if (arr == nullptr)return;
	delete arr;
	arr = nullptr;
	return;
}

void ArrayAllocHelper::deallocate(double **& arr, int size)
{
	if (arr == nullptr) return;
	for (int i = 0; i < size; i++) {
		deallocate(arr[i]);
	}
	arr = nullptr;
}
